package com.example.buiss

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.painter.Painter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.buiss.ui.theme.BuissTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            BuissTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { paddingIntern ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(paddingIntern)
                    ) {
                        FonsImatge(modifier = Modifier.fillMaxSize())

                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(paddingIntern),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = "Repte01",
                                modifier = Modifier.padding(bottom = 24.dp)
                            )

                            PantallaSeleccio()
                            Spacer(modifier = Modifier.height(24.dp))
                            PantallaAjustarMinMax()
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun FonsImatge(modifier: Modifier = Modifier) {
    val imatgeDeFons: Painter = painterResource(id = R.drawable.background_image)
    Image(
        painter = imatgeDeFons,
        contentDescription = null,
        modifier = modifier
    )
}

@Composable
fun PantallaSeleccio() {
    var opcioSeleccionada by remember { mutableStateOf("Afegir") }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Button(
            onClick = { },
            modifier = Modifier.fillMaxWidth().padding(8.dp)
        ) {
            Text("Tria una icona")
        }
        Text(text = "Selecciona una opció:")
        GrupBotonsOpcio(
            opcions = listOf("Afegir", "Trucar", "Correu"),
            opcioSeleccionada = opcioSeleccionada,
            enOpcioSeleccionada = { opcioSeleccionada = it }
        )
    }
}

@Composable
fun GrupBotonsOpcio(
    opcions: List<String>,
    opcioSeleccionada: String,
    enOpcioSeleccionada: (String) -> Unit
) {
    Column {
        opcions.forEach { opcio ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                RadioButton(
                    selected = (opcio == opcioSeleccionada),
                    onClick = { enOpcioSeleccionada(opcio) }
                )
                Text(text = opcio, modifier = Modifier.padding(start = 8.dp))
            }
        }
    }
}

@Composable
fun PantallaAjustarMinMax() {
    var valorMinim by remember { mutableStateOf(0) }
    var valorMaxim by remember { mutableStateOf(10) }
    var iconaGenerada by remember { mutableStateOf<Int?>(null) }

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Ajusta el valor mínim i màxim")

        Spacer(modifier = Modifier.height(8.dp))

        ControlValor(
            etiqueta = "Mínim:",
            valor = valorMinim,
            enDecrementar = { if (valorMinim > 0) valorMinim-- },
            enIncrementar = { if (valorMinim < valorMaxim) valorMinim++ }
        )

        ControlValor(
            etiqueta = "Màxim:",
            valor = valorMaxim,
            enDecrementar = { if (valorMaxim > valorMinim) valorMaxim-- },
            enIncrementar = { if (valorMaxim < 10) valorMaxim++ }
        )

        Spacer(modifier = Modifier.height(16.dp))

        BarraProgres(valorMinim, valorMaxim)

        Spacer(modifier = Modifier.height(16.dp))

        Button(onClick = {
            iconaGenerada = valorMinim
        }) {
            Text("Enviar")
        }

        iconaGenerada?.let { icona ->
            Spacer(modifier = Modifier.height(16.dp))
            IconaAmbNumero(icona)
        }
    }
}

@Composable
fun ControlValor(etiqueta: String, valor: Int, enDecrementar: () -> Unit, enIncrementar: () -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(8.dp)) {
        Text(text = "$etiqueta $valor")
        Spacer(modifier = Modifier.width(16.dp))
        Button(onClick = enDecrementar, enabled = valor > 0) { Text("-") }
        Spacer(modifier = Modifier.width(8.dp))
        Button(onClick = enIncrementar, enabled = valor < 10) { Text("+") }
    }
}

@Preview(showBackground = true)
@Composable
fun PantallaPrevisualitzacio() {
    BuissTheme {
        Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            PantallaSeleccio()
            Spacer(modifier = Modifier.height(24.dp))
            PantallaAjustarMinMax()
        }
    }
}

@Composable
fun BarraProgres(valorMinim: Int, valorMaxim: Int) {
    val progress = (valorMinim.toFloat() / valorMaxim.toFloat()).coerceIn(0f, 1f)

    val colorAzul = Color(0xFF0066CC)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = "Progrés: $valorMinim / $valorMaxim")
        Spacer(modifier = Modifier.height(8.dp))

        LinearProgressIndicator(
            progress = progress,
            color = colorAzul,
            modifier = Modifier.fillMaxWidth().height(8.dp)
        )
    }
}

@Composable
fun IconaAmbNumero(numero: Int) {
    val icona: Painter = painterResource(id = when (numero) {
        0 -> R.drawable.icon1
        1 -> R.drawable.icon2
        2 -> R.drawable.icon3
        3 -> R.drawable.icon4
        else -> R.drawable.icon1
    })

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Image(
            painter = icona,
            contentDescription = "Ícono generat",
            modifier = Modifier.size(48.dp)
        )
    }
}
